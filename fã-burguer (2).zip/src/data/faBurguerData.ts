export const RESTAURANT_INFO = {
  name: 'Fã Burguer',
  address: 'Av. Conde da Boa Vista, 1223 - Boa Vista, Recife - PE, 52171-011, Brasil',
  shortAddress: 'Av. Conde da Boa Vista, 1223 · Boa Vista, Recife',
  phoneDisplay: '+55 (81) 3231-1067',
  phoneRaw: '558132311067',
  hours: 'Terça a Domingo · 11h30 às 23h30',
  email: 'contato@faburguer.com.br',
} as const;

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${RESTAURANT_INFO.phoneRaw}?text=${encodeURIComponent(message)}`;
}

export function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

export type MenuCategory = 'Clássicos' | 'Especiais na Brasa' | 'Acompanhamentos' | 'Bebidas';

export interface MenuItem {
  id: string;
  name: string;
  category: MenuCategory;
  spec: string;
  description: string;
  price: number;
  image?: string;
  alt: string;
  highlightNote?: string;
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'conde-classico',
    name: 'Conde Clássico 180g',
    category: 'Clássicos',
    spec: 'Blend Bovino 180g · Brioche Artesanal',
    description:
      'Hambúrguer de acém e peito moídos diariamente na casa, cheddar inglês maturado, alface americana, tomate caqui, cebola roxa e molho da casa no brioche selado na manteiga.',
    price: 38.9,
    image: '/src/assets/images/menu_classico_boa_vista_1795620710241.jpg',
    alt: 'Hambúrguer Conde Clássico 180g com queijo cheddar derretido e vegetais frescos em prato escuro',
    highlightNote: 'Mais pedido no salão',
  },
  {
    id: 'brasa-costela',
    name: 'Brasa Costela & Bacon',
    category: 'Especiais na Brasa',
    spec: 'Blend 180g + Costela Desfiada · Defumado',
    description:
      'Corte alto grelhado no carvão, costela bovina desfiada por 8 horas, queijo provolone maçaricado, bacon artesanal espesso e geleia de cebola caramelizada no vinho tinto.',
    price: 49.9,
    image: '/src/assets/images/menu_brasa_costela_1795620710658.jpg',
    alt: 'Hambúrguer Brasa Costela & Bacon acompanhado de fritas rústicas em pedra ardósia',
    highlightNote: 'Assinatura do Chef',
  },
  {
    id: 'duplo-executivo',
    name: 'Duplo Smash Boa Vista',
    category: 'Clássicos',
    spec: '2× 100g Smash · Crosta Caramelizada',
    description:
      'Dois discos prensados na chapa de ferro fundido para máxima caramelização, dupla camada de queijo prato, picles da casa, cebola roxa e aioli defumado.',
    price: 42.9,
    image: '/src/assets/images/menu_combo_executivo_1795620715541.jpg',
    alt: 'Duplo Smash Boa Vista servido com batatas rústicas ao alecrim e aioli defumado',
  },
  {
    id: 'reserva-gorgonzola',
    name: 'Reserva Gorgonzola & Rúcula',
    category: 'Especiais na Brasa',
    spec: 'Blend Angus 200g · Creme de Gorgonzola',
    description:
      'Corte nobre grelhado ao ponto da casa, creme aveludado de queijo gorgonzola, rúcula selvagem fresca e redução balsâmica em pão australiano tostado.',
    price: 52.9,
    image: '/src/assets/images/hero_fa_burguer_1795620710839.jpg',
    alt: 'Hambúrguer Reserva Gorgonzola servido na tábua de ardósia em ambiente noturno',
  },
  {
    id: 'fritas-alecrim',
    name: 'Fritas Rústicas ao Alecrim',
    category: 'Acompanhamentos',
    spec: 'Porção 300g · Flor de Sal & Aioli',
    description:
      'Batatas selecionadas cortadas manualmente em gomos, fritas em dupla imersão, finalizadas com alecrim fresco, flor de sal e ramequim de aioli defumado.',
    price: 24.9,
    image: '/src/assets/images/menu_combo_executivo_1795620715541.jpg',
    alt: 'Porção de batatas rústicas temperadas com alecrim fresco e molho aioli',
  },
  {
    id: 'chopp-artesanal',
    name: 'Chopp IPA & Soda Italiana',
    category: 'Bebidas',
    spec: '500ml Gelado · Seleção da Casa',
    description:
      'Chopp artesanal pernambucano tirado na pressão a zero grau ou nossa soda italiana autoral de frutas vermelhas com hortelã fresca.',
    price: 18.9,
    image: '/src/assets/images/gallery_salao_recife_1795620712623.jpg',
    alt: 'Bar principal do salão da Fã Burguer com seleção de bebidas e chopes artesanais',
  },
];

export interface CorporateService {
  number: string;
  title: string;
  summary: string;
  detail: string;
  whatsappPrompt: string;
}

export const CORPORATE_SERVICES: CorporateService[] = [
  {
    number: '01.',
    title: 'Almoço Executivo & Delivery Corporativo',
    summary: 'Entregas pontuais no eixo Boa Vista, Derby, Ilha do Leite e Recife Antigo.',
    detail:
      'Embalagens térmicas estruturadas que preservam a crocância do pão e a temperatura da brasa. Condições diferenciadas para pedidos recorrentes de empresas e clínicas.',
    whatsappPrompt:
      'Olá, Fã Burguer! Gostaria de informações sobre pedidos e convênio corporativo para almoço executivo.',
  },
  {
    number: '02.',
    title: 'Eventos Empresariais & Coffee-Burger',
    summary: 'Cardápio sob medida para reuniões de diretoria, treinamentos e confraternizações.',
    detail:
      'Montagem de kits individuais identificados por colaborador ou serviço completo com mini burgers artesanais, fritas rústicas e bebidas.',
    whatsappPrompt:
      'Olá, Fã Burguer! Gostaria de solicitar um orçamento de kits corporativos para um evento empresarial.',
  },
  {
    number: '03.',
    title: 'Reservas de Salão & Reuniões',
    summary: 'Ambiente climatizado, acústica confortável e atendimento dedicado na Av. Conde da Boa Vista.',
    detail:
      'Mesas reservadas para almoços de negócios, recepção de clientes ou comemorações reservadas com atendimento prioritário.',
    whatsappPrompt:
      'Olá, Fã Burguer! Gostaria de verificar disponibilidade para reserva de mesa no salão.',
  },
];

export interface GalleryPhoto {
  id: string;
  src: string;
  alt: string;
  title: string;
  category: string;
  description: string;
}

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'salao',
    src: '/src/assets/images/gallery_salao_recife_1795620712623.jpg',
    alt: 'Salão principal da Fã Burguer com iluminação em cobre e cabines em couro vinho',
    title: 'Salão Principal · Boa Vista',
    category: 'Arquitetura & Ambiente',
    description:
      'Projeto luminotécnico em cobre escovado, estofados em couro bordô e atendimento pensado para conforto executivo.',
  },
  {
    id: 'cozinha',
    src: '/src/assets/images/gallery_cozinha_brasa_1795620713081.jpg',
    alt: 'Chef grelhando blends artesanais sobre brasa viva na cozinha da Fã Burguer',
    title: 'Cozinha Aberta na Brasa',
    category: 'Preparo & Rigor',
    description:
      'Grelha a carvão controlada em alta temperatura para selagem imediata dos sucos naturais da carne.',
  },
  {
    id: 'duplo-mesa',
    src: '/src/assets/images/hero_fa_burguer_1795620710839.jpg',
    alt: 'Hambúrguer duplo artesanal servido com fritas e chopp artesanal',
    title: 'Experiência Completa à Mesa',
    category: 'Gastronomia',
    description:
      'Harmonização de cortes frescos 180g com pães de fermentação natural e rótulos artesanais.',
  },
  {
    id: 'costela-brasa',
    src: '/src/assets/images/menu_brasa_costela_1795620710658.jpg',
    alt: 'Brasa Costela & Bacon servido com batatas rústicas em pedra ardósia',
    title: 'Brasa Costela & Bacon',
    category: 'Assinatura da Casa',
    description:
      '8 horas de cocção lenta na costela bovina combinadas com bacon crocante e geleia de cebola.',
  },
  {
    id: 'classico',
    src: '/src/assets/images/menu_classico_boa_vista_1795620710241.jpg',
    alt: 'Conde Clássico 180g em prato cerâmico preto',
    title: 'Conde Clássico 180g',
    category: 'Clássicos',
    description:
      'Equilíbrio preciso entre cheddar inglês maturado, vegetais selecionados e molho autoral.',
  },
  {
    id: 'executivo',
    src: '/src/assets/images/menu_combo_executivo_1795620715541.jpg',
    alt: 'Duplo Smash Boa Vista com batatas ao alecrim e aioli',
    title: 'Almoço Executivo Boa Vista',
    category: 'Serviço Ágil',
    description:
      'Combinação preparada em menos de 18 minutos para quem valoriza qualidade na pausa do expediente.',
  },
];

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  organization: string;
  neighborhood: string;
  context: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'mariana',
    quote:
      'Passamos a encomendar os combos executivos da Fã Burguer para todas as reuniões mensais da nossa diretoria. As embalagens chegam impecáveis na Ilha do Leite e o ponto da carne nunca varia.',
    author: 'Mariana Cavalcanti',
    role: 'Diretora Financeira',
    organization: 'Grupo Boa Vista Saúde',
    neighborhood: 'Boa Vista, Recife',
    context: 'Pedido corporativo recorrente há 2 anos',
  },
  {
    id: 'rafael',
    quote:
      'É raro encontrar uma hamburgueria no centro do Recife com ambiente silencioso, climatizado e atendimento ágil o suficiente para receber clientes de fora no almoço sem perder qualidade.',
    author: 'Rafael Albuquerque',
    role: 'Sócio-Fundador',
    organization: 'Albuquerque & Associados Advocacia',
    neighborhood: 'Derby, Recife',
    context: 'Cliente frequente do salão executivo',
  },
  {
    id: 'fernanda',
    quote:
      'Pelo WhatsApp o atendimento é direto e sem burocracia: em poucos minutos confirmam o pedido e entregam no horário combinado. O Brasa Costela já virou referência na nossa equipe.',
    author: 'Fernanda Lima',
    role: 'Produtora Executiva',
    organization: 'Porto Eventos Culturais',
    neighborhood: 'Recife Antigo',
    context: 'Catering para 45 pessoas via WhatsApp',
  },
];

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-1',
    question: 'Qual é o endereço exato da Fã Burguer e há facilidade de acesso?',
    answer:
      'Estamos localizados na Av. Conde da Boa Vista, 1223 - Boa Vista, Recife - PE, CEP 52171-011, próximo ao cruzamento com a Rua Dom Bosco. Contamos com embarque rápido para retirada no balcão e convênio com estacionamento rotativo a 40 metros da entrada.',
  },
  {
    id: 'faq-2',
    question: 'Como faço meu pedido ou reserva diretamente pelo WhatsApp?',
    answer:
      'Você pode montar seu pedido aqui mesmo no cardápio clicando em "Adicionar ao Pedido" e depois em "Enviar Pedido no WhatsApp", ou iniciar uma conversa direta pelo número +55 (81) 3231-1067. Nossa equipe confirma o preparo imediatamente.',
  },
  {
    id: 'faq-3',
    question: 'Vocês atendem empresas, clínicas e eventos corporativos no Recife?',
    answer:
      'Sim. Possuímos operação dedicada para encomendas empresariais, reuniões executivas e confraternizações, com emissão de nota fiscal, embalagens identificadas por nome e agendamento de horário para entregas na Boa Vista, Derby, Ilha do Leite, Graças, Espinheiro e Recife Antigo.',
  },
  {
    id: 'faq-4',
    question: 'É possível ajustar o ponto da carne ou solicitar opções sem carne?',
    answer:
      'Nossos blends de 180g saem no ponto da casa (suculento e rosado ao centro), mas você pode solicitar bem passado ou ao ponto para menos nas observações do pedido. Também preparamos todos os lanches com hambúrguer artesanal de cogumelos e grão-de-bico sob consulta.',
  },
  {
    id: 'faq-5',
    question: 'Quais formas de pagamento são aceitas no salão e no delivery?',
    answer:
      'Aceitamos Pix, cartões de crédito e débito das principais bandeiras, vale-refeição (Alelo, Sodexo/Pluxee, Ticket e VR) no salão e na entrega, além de faturamento corporativo programado para empresas cadastradas.',
  },
];
