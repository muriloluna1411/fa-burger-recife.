import {useEffect, useState} from 'react';
import {AlertCircle, CheckCircle2, MessageCircle, Minus, Plus, ShoppingBag, Trash2, X} from 'lucide-react';
import {buildWhatsAppUrl, formatBRL, MenuItem, RESTAURANT_INFO} from '../data/faBurguerData';

export interface CartEntry {
  item: MenuItem;
  quantity: number;
}

interface WhatsAppOrderDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartEntry[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

type ServiceMode = 'Delivery' | 'Retirada no Balcão' | 'Reserva no Salão';
type PaymentMethod = 'Pix' | 'Cartão na Entrega / Salão' | 'Vale-Refeição';

export function WhatsAppOrderDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: WhatsAppOrderDrawerProps) {
  const [customerName, setCustomerName] = useState('');
  const [serviceMode, setServiceMode] = useState<ServiceMode>('Delivery');
  const [addressOrNote, setAddressOrNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Pix');
  const [validationError, setValidationError] = useState('');
  const [dispatched, setDispatched] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, entry) => sum + entry.item.price * entry.quantity, 0);

  const generateOrderMessage = () => {
    const lines: string[] = [
      `Olá, *Fã Burguer*! Gostaria de iniciar meu atendimento:`,
      '',
    ];

    if (cart.length > 0) {
      lines.push('*Itens Selecionados:*');
      cart.forEach((entry) => {
        lines.push(
          `• ${entry.quantity}x ${entry.item.name} — ${formatBRL(entry.item.price * entry.quantity)}`
        );
      });
      lines.push('');
      lines.push(`*Total Estimado:* ${formatBRL(subtotal)}`);
      lines.push('');
    } else {
      lines.push('Gostaria de fazer um pedido ou consultar o atendimento do dia.');
      lines.push('');
    }

    lines.push(`*Modalidade:* ${serviceMode}`);
    lines.push(`*Pagamento:* ${paymentMethod}`);
    if (customerName.trim()) {
      lines.push(`*Nome:* ${customerName.trim()}`);
    }
    if (addressOrNote.trim()) {
      lines.push(`*Endereço / Observações:* ${addressOrNote.trim()}`);
    }

    return lines.join('\n');
  };

  const whatsappHref = buildWhatsAppUrl(generateOrderMessage());

  const handleDispatchClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (cart.length > 0 && serviceMode === 'Delivery' && addressOrNote.trim().length < 5) {
      e.preventDefault();
      setValidationError(
        'Informe o endereço ou ponto de referência para entrega na região do Recife.'
      );
      return;
    }
    setValidationError('');
    setDispatched(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="drawer-title"
    >
      <div className="absolute inset-0" onClick={onClose} aria-hidden="true" />

      <aside className="relative z-10 w-full max-w-md bg-white h-full flex flex-col border-l border-stone-200 shadow-2xl">
        {/* Drawer Header */}
        <div className="px-6 py-5 border-b border-stone-200 flex items-center justify-between gap-4">
          <div>
            <h2 id="drawer-title" className="font-display text-xl font-bold text-[#1F1C1A]">
              Atendimento via WhatsApp
            </h2>
            <p className="text-xs text-stone-500 mt-0.5 tabular-nums">
              {RESTAURANT_INFO.phoneDisplay} · Resposta imediata
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar painel de pedido"
            className="w-10 h-10 inline-flex items-center justify-center rounded-md border border-stone-200 text-stone-600 hover:text-[#1F1C1A] hover:bg-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
          {/* Cart Items */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-[#1F1C1A]">
                Resumo do Pedido ({cart.reduce((acc, c) => acc + c.quantity, 0)})
              </span>
              {cart.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    onClearCart();
                    setDispatched(false);
                  }}
                  className="text-xs font-medium text-stone-500 hover:text-[#8c1212] transition-colors cursor-pointer"
                >
                  Limpar itens
                </button>
              )}
            </div>

            {cart.length === 0 ? (
              <div className="border border-stone-200 bg-[#F6F6F5] rounded-lg p-5 text-center space-y-2">
                <ShoppingBag className="w-6 h-6 text-[#a65821] mx-auto" aria-hidden="true" />
                <p className="text-sm font-medium text-[#1F1C1A]">
                  Nenhum item selecionado ainda
                </p>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Você pode adicionar hambúrgueres do cardápio para enviar o pedido pronto ou iniciar
                  uma conversa direta pelo WhatsApp abaixo.
                </p>
              </div>
            ) : (
              <ul className="divide-y divide-stone-200 border border-stone-200 rounded-lg bg-white">
                {cart.map(({item, quantity}) => (
                  <li key={item.id} className="p-4 flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#1F1C1A] truncate">{item.name}</p>
                      <p className="text-xs text-stone-500 tabular-nums mt-0.5">
                        {formatBRL(item.price)} cada
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <div className="flex items-center border border-stone-200 rounded-md">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.id, -1)}
                          aria-label={`Diminuir quantidade de ${item.name}`}
                          className="w-8 h-8 inline-flex items-center justify-center text-stone-600 hover:bg-stone-100 cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-7 text-center text-xs font-semibold tabular-nums text-[#1F1C1A]">
                          {quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.id, 1)}
                          aria-label={`Aumentar quantidade de ${item.name}`}
                          className="w-8 h-8 inline-flex items-center justify-center text-stone-600 hover:bg-stone-100 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.id)}
                        aria-label={`Remover ${item.name}`}
                        className="w-8 h-8 inline-flex items-center justify-center text-stone-400 hover:text-[#8c1212] cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Service Mode Selector */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-[#1F1C1A]">
              Modalidade de Atendimento
            </label>
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#F6F6F5] rounded-lg border border-stone-200">
              {(['Delivery', 'Retirada no Balcão', 'Reserva no Salão'] as ServiceMode[]).map(
                (mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => {
                      setServiceMode(mode);
                      setValidationError('');
                    }}
                    className={`px-2 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer truncate ${
                      serviceMode === mode
                        ? 'bg-white text-[#8c1212] shadow-sm font-semibold'
                        : 'text-stone-600 hover:text-[#1F1C1A]'
                    }`}
                    title={mode}
                  >
                    {mode === 'Retirada no Balcão'
                      ? 'Retirada'
                      : mode === 'Reserva no Salão'
                      ? 'Salão'
                      : 'Delivery'}
                  </button>
                )
              )}
            </div>
          </div>

          {/* Customer Details */}
          <div className="space-y-4">
            <div>
              <label
                htmlFor="drawer-name"
                className="block text-xs font-semibold text-stone-700 mb-1.5"
              >
                Seu nome
              </label>
              <input
                id="drawer-name"
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Ex.: Mariana Cavalcanti"
                className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] placeholder:text-stone-400 focus:outline-none focus:border-[#8c1212]"
              />
            </div>

            <div>
              <label
                htmlFor="drawer-note"
                className="block text-xs font-semibold text-stone-700 mb-1.5"
              >
                {serviceMode === 'Delivery'
                  ? 'Endereço de entrega em Recife (rua, número, complemento)'
                  : serviceMode === 'Reserva no Salão'
                  ? 'Horário desejado e número de pessoas'
                  : 'Horário de retirada ou observação do ponto da carne'}
              </label>
              <textarea
                id="drawer-note"
                rows={2}
                value={addressOrNote}
                onChange={(e) => {
                  setAddressOrNote(e.target.value);
                  if (validationError) setValidationError('');
                }}
                placeholder={
                  serviceMode === 'Delivery'
                    ? 'Ex.: Rua do Paissandu, 410 - Boa Vista, Sala 302'
                    : 'Ex.: Carne ao ponto da casa, sem cebola'
                }
                className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] placeholder:text-stone-400 focus:outline-none focus:border-[#8c1212]"
              />
            </div>

            <div>
              <label
                htmlFor="drawer-payment"
                className="block text-xs font-semibold text-stone-700 mb-1.5"
              >
                Forma de pagamento preferida
              </label>
              <select
                id="drawer-payment"
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] focus:outline-none focus:border-[#8c1212]"
              >
                <option value="Pix">Pix</option>
                <option value="Cartão na Entrega / Salão">Cartão (Crédito / Débito)</option>
                <option value="Vale-Refeição">Vale-Refeição (Alelo / Ticket / Pluxee / VR)</option>
              </select>
            </div>
          </div>

          {validationError && (
            <div
              role="alert"
              className="flex items-start gap-2.5 p-3 rounded-md bg-red-50 border border-red-200 text-xs text-[#8c1212]"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
              <span>{validationError}</span>
            </div>
          )}

          {dispatched && (
            <div
              role="status"
              className="flex items-start gap-2.5 p-3 rounded-md bg-emerald-50 border border-emerald-200 text-xs text-emerald-900"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-700" aria-hidden="true" />
              <span>
                Resumo preparado para o WhatsApp oficial da Fã Burguer. Caso a janela não tenha
                aberto, clique novamente no botão abaixo.
              </span>
            </div>
          )}
        </div>

        {/* Drawer Footer */}
        <div className="px-6 py-5 border-t border-stone-200 bg-[#F6F6F5] space-y-3">
          {cart.length > 0 && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-stone-600 font-medium">Subtotal dos itens</span>
              <span className="text-lg font-bold text-[#1F1C1A] tabular-nums">
                {formatBRL(subtotal)}
              </span>
            </div>
          )}

          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            onClick={handleDispatchClick}
            className="w-full inline-flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-md bg-[#8c1212] hover:bg-[#700d0d] text-white text-sm font-semibold transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>
              {cart.length > 0 ? 'Enviar Pedido no WhatsApp' : 'Iniciar Conversa no WhatsApp'}
            </span>
          </a>
        </div>
      </aside>
    </div>
  );
}
