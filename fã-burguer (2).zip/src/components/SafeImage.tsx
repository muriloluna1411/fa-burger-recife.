import {useState} from 'react';
import {UtensilsCrossed} from 'lucide-react';

interface SafeImageProps {
  src?: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export function SafeImage({src, alt, className = '', fallbackTitle}: SafeImageProps) {
  const [hasError, setHasError] = useState(false);

  if (!src || hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#231f1d] via-[#1b1817] to-[#2e1616] text-stone-300 p-6 text-center ${className}`}
      >
        <UtensilsCrossed className="w-7 h-7 text-[#a65821] mb-2" aria-hidden="true" />
        <span className="font-display text-sm font-semibold text-stone-100">
          {fallbackTitle || 'Fã Burguer'}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
