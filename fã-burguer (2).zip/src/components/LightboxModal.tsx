import {useEffect} from 'react';
import {ChevronLeft, ChevronRight, X} from 'lucide-react';
import {GalleryPhoto} from '../data/faBurguerData';
import {SafeImage} from './SafeImage';

interface LightboxModalProps {
  photos: GalleryPhoto[];
  activeIndex: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
}

export function LightboxModal({photos, activeIndex, onClose, onNavigate}: LightboxModalProps) {
  useEffect(() => {
    if (activeIndex === null) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') {
        onNavigate((activeIndex - 1 + photos.length) % photos.length);
      }
      if (e.key === 'ArrowRight') {
        onNavigate((activeIndex + 1) % photos.length);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, photos.length, onClose, onNavigate]);

  if (activeIndex === null) return null;
  const current = photos[activeIndex];
  if (!current) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 sm:p-8"
      role="dialog"
      aria-modal="true"
      aria-labelledby="lightbox-title"
    >
      <div className="absolute inset-0" onClick={onClose} aria-hidden="true" />

      <div className="relative z-10 w-full max-w-4xl bg-[#181615] border border-stone-800 rounded-lg overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-stone-800">
          <div className="flex items-center gap-2 text-xs text-stone-400">
            <span>{current.category}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              {activeIndex + 1} / {photos.length}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar visualização da foto"
            className="w-9 h-9 inline-flex items-center justify-center rounded-md text-stone-300 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative bg-black aspect-[16/10] w-full">
          <SafeImage
            src={current.src}
            alt={current.alt}
            fallbackTitle={current.title}
            className="w-full h-full object-cover"
          />

          <button
            type="button"
            onClick={() => onNavigate((activeIndex - 1 + photos.length) % photos.length)}
            aria-label="Foto anterior"
            className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 inline-flex items-center justify-center rounded-full bg-black/70 text-white hover:bg-[#8c1212] transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => onNavigate((activeIndex + 1) % photos.length)}
            aria-label="Próxima foto"
            className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 inline-flex items-center justify-center rounded-full bg-black/70 text-white hover:bg-[#8c1212] transition-colors cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 py-4 bg-[#181615]">
          <h3 id="lightbox-title" className="font-display text-lg font-semibold text-white">
            {current.title}
          </h3>
          <p className="text-sm text-stone-300 mt-1 leading-relaxed">{current.description}</p>
        </div>
      </div>
    </div>
  );
}
