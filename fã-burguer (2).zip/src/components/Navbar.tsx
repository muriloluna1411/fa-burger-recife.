import {useState} from 'react';
import {Menu, MessageCircle, X} from 'lucide-react';
import {buildWhatsAppUrl, RESTAURANT_INFO} from '../data/faBurguerData';

const NAV_LINKS = [
  {href: '#cardapio', label: 'Cardápio'},
  {href: '#servicos', label: 'Corporativo'},
  {href: '#galeria', label: 'Galeria'},
  {href: '#depoimentos', label: 'Depoimentos'},
  {href: '#contato', label: 'Contato'},
];

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-stone-200">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#inicio"
          className="font-display text-xl sm:text-2xl font-bold tracking-tight text-[#1F1C1A] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#8c1212]"
        >
          {RESTAURANT_INFO.name}
        </a>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-600"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="relative py-1 hover:text-[#8c1212] transition-colors whitespace-nowrap shrink-0 after:absolute after:left-0 after:bottom-0 after:h-[1.5px] after:w-0 after:bg-[#8c1212] hover:after:w-full after:transition-all focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#8c1212]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1 primary action (+ mobile menu trigger on small viewports) */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={buildWhatsAppUrl('Olá, Fã Burguer! Gostaria de falar com o atendimento.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[40px] rounded-md bg-[#8c1212] hover:bg-[#700d0d] text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#8c1212]"
          >
            <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Falar no WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-md border border-stone-200 text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <nav
          aria-label="Navegação móvel"
          className="md:hidden border-t border-stone-200 bg-white px-4 py-4 space-y-1"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-3 text-base font-medium text-stone-800 hover:bg-stone-50 hover:text-[#8c1212] rounded-md transition-colors"
            >
              {item.label}
            </a>
          ))}
          <a
            href="#faq"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-3 text-base font-medium text-stone-800 hover:bg-stone-50 hover:text-[#8c1212] rounded-md transition-colors"
          >
            Perguntas Frequentes
          </a>
        </nav>
      )}
    </header>
  );
}
