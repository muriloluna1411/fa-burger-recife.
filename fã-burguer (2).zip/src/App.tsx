import {FormEvent, useMemo, useState} from 'react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock,
  Copy,
  MapPin,
  MessageCircle,
  Phone,
} from 'lucide-react';
import {LightboxModal} from './components/LightboxModal';
import {Navbar} from './components/Navbar';
import {SafeImage} from './components/SafeImage';
import {
  buildWhatsAppUrl,
  CORPORATE_SERVICES,
  FAQ_ITEMS,
  formatBRL,
  GALLERY_PHOTOS,
  MENU_ITEMS,
  MenuCategory,
  RESTAURANT_INFO,
  TESTIMONIALS,
} from './data/faBurguerData';

type FilterTab = 'Todos' | MenuCategory;

const FILTER_TABS: FilterTab[] = [
  'Todos',
  'Clássicos',
  'Especiais na Brasa',
  'Acompanhamentos',
  'Bebidas',
];

export default function App() {
  const [activeCategory, setActiveCategory] = useState<FilterTab>('Todos');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [openFaqId, setOpenFaqId] = useState<string | null>(FAQ_ITEMS[0].id);
  const [phoneCopied, setPhoneCopied] = useState(false);

  // Contact form state
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('Reserva de Mesa');
  const [contactMessage, setContactMessage] = useState('');
  const [contactError, setContactError] = useState('');
  const [contactSubmitted, setContactSubmitted] = useState(false);

  const filteredMenu = useMemo(() => {
    if (activeCategory === 'Todos') return MENU_ITEMS;
    return MENU_ITEMS.filter((item) => item.category === activeCategory);
  }, [activeCategory]);

  const handleCopyPhone = async () => {
    try {
      await navigator.clipboard.writeText(RESTAURANT_INFO.phoneDisplay);
      setPhoneCopied(true);
      window.setTimeout(() => setPhoneCopied(false), 2000);
    } catch {
      setPhoneCopied(false);
    }
  };

  const handleContactSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmedName = contactName.trim();
    const trimmedPhone = contactPhone.trim();
    const trimmedEmail = contactEmail.trim();
    const trimmedMessage = contactMessage.trim();

    if (trimmedName.length < 2) {
      setContactError('Informe seu nome completo para registrarmos seu atendimento.');
      return;
    }

    const phoneDigits = trimmedPhone.replace(/\D/g, '');
    if (phoneDigits.length < 10) {
      setContactError('Informe um número de telefone ou WhatsApp válido com DDD.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      setContactError('Informe um endereço de e-mail válido.');
      return;
    }

    if (trimmedMessage.length < 10) {
      setContactError('Escreva uma breve mensagem descrevendo sua solicitação ou reserva.');
      return;
    }

    setContactError('');
    setContactSubmitted(true);
  };

  const contactWhatsAppHref = buildWhatsAppUrl(
    [
      `Olá, *Fã Burguer*!`,
      `*Assunto:* ${contactSubject}`,
      contactName ? `*Nome:* ${contactName}` : '',
      contactPhone ? `*Telefone:* ${contactPhone}` : '',
      contactEmail ? `*E-mail:* ${contactEmail}` : '',
      contactMessage ? `*Mensagem:* ${contactMessage}` : '',
    ]
      .filter(Boolean)
      .join('\n')
  );

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#1F1C1A]">
      <Navbar />

      <main className="flex-1">
        {/* HERO SECTION */}
        <section id="inicio" className="bg-[#181615] text-white border-b border-stone-800">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-12 lg:py-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
              <div className="lg:col-span-6 flex flex-col justify-center py-2">
                <p className="text-xs sm:text-sm font-medium text-[#e0915a] tracking-wide mb-4">
                  Av. Conde da Boa Vista, 1223 · Boa Vista, Recife
                </p>

                <h1
                  className="font-display font-bold tracking-tight text-white leading-[1.12] text-balance"
                  style={{fontSize: 'clamp(2.25rem, 4vw, 3.65rem)'}}
                >
                  Hamburgueria artesanal de padrão executivo no coração do Recife.
                </h1>

                <p className="mt-5 text-base sm:text-lg text-stone-300 leading-relaxed max-w-xl">
                  Blends bovinos frescos de 180g grelhados na brasa, pão brioche de fermentação
                  natural e atendimento ágil no salão ou diretamente pelo WhatsApp.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-5">
                  <a
                    href={buildWhatsAppUrl(
                      'Olá, Fã Burguer! Gostaria de fazer um pedido ou reserva.'
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-md bg-[#8c1212] hover:bg-[#700d0d] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                  >
                    <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>Fazer Pedido no WhatsApp</span>
                  </a>

                  <a
                    href="#cardapio"
                    className="inline-flex items-center gap-2 py-2 text-sm font-semibold text-stone-200 hover:text-[#e0915a] transition-colors whitespace-nowrap shrink-0"
                  >
                    <span>Explorar o Cardápio</span>
                    <ArrowRight className="w-4 h-4" aria-hidden="true" />
                  </a>
                </div>
              </div>

              <div className="lg:col-span-6">
                <div className="h-full min-h-[280px] sm:min-h-[360px] rounded-lg overflow-hidden border border-stone-800 bg-[#231f1d]">
                  <SafeImage
                    src="/src/assets/images/hero_fa_burguer_1795620710839.jpg"
                    alt="Hambúrguer artesanal duplo da Fã Burguer servido na tábua de ardósia com fritas e chopp no salão"
                    fallbackTitle="Fã Burguer · Boa Vista"
                    className="w-full h-full lg:h-full object-cover"
                  />
                </div>
              </div>
            </div>

            {/* Full-width 4-column institutional strip below hero split */}
            <div className="mt-12 pt-8 border-t border-stone-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
              <div>
                <p className="text-xs font-medium text-stone-400">01. Endereço Central</p>
                <p className="mt-1 text-sm font-semibold text-white">
                  Av. Conde da Boa Vista, 1223
                </p>
                <p className="text-xs text-stone-400 mt-0.5">Boa Vista · Recife - PE</p>
              </div>
              <div>
                <p className="text-xs font-medium text-stone-400">02. Pedido e Reservas</p>
                <p className="mt-1 text-sm font-semibold text-white tabular-nums">
                  {RESTAURANT_INFO.phoneDisplay}
                </p>
                <p className="text-xs text-stone-400 mt-0.5">Atendimento direto no WhatsApp</p>
              </div>
              <div>
                <p className="text-xs font-medium text-stone-400">03. Horário de Operação</p>
                <p className="mt-1 text-sm font-semibold text-white">Terça a Domingo</p>
                <p className="text-xs text-stone-400 mt-0.5 tabular-nums">11h30 às 23h30</p>
              </div>
              <div>
                <p className="text-xs font-medium text-stone-400">04. Padrão Gastronômico</p>
                <p className="mt-1 text-sm font-semibold text-white">Blends Frescos na Brasa</p>
                <p className="text-xs text-stone-400 mt-0.5">Moagem diária de cortes nobres</p>
              </div>
            </div>
          </div>
        </section>

        {/* CARDÁPIO SECTION */}
        <section id="cardapio" className="py-16 lg:py-24 bg-white">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-stone-200">
              <div className="max-w-2xl">
                <p className="text-xs font-semibold text-[#a65821] tracking-wide mb-2">
                  Cardápio Autoral
                </p>
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1F1C1A] tracking-tight text-balance">
                  Seleção da Casa na Brasa
                </h2>
                <p className="mt-3 text-base text-stone-600 leading-relaxed">
                  Cortes selecionados grelhados na brasa, preparados diariamente na nossa unidade da
                  Boa Vista.
                </p>
              </div>

              {/* Interactive Category Filter Controls */}
              <div
                role="tablist"
                aria-label="Categorias do cardápio"
                className="flex flex-wrap items-center gap-1.5 p-1 bg-[#F6F6F5] border border-stone-200 rounded-lg self-start md:self-auto"
              >
                {FILTER_TABS.map((tab) => {
                  const isActive = activeCategory === tab;
                  return (
                    <button
                      key={tab}
                      type="button"
                      role="tab"
                      aria-selected={isActive}
                      onClick={() => setActiveCategory(tab)}
                      className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        isActive
                          ? 'bg-white text-[#8c1212] shadow-sm'
                          : 'text-stone-600 hover:text-[#1F1C1A]'
                      }`}
                    >
                      {tab}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Menu Grid */}
            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredMenu.map((item) => (
                <article
                  key={item.id}
                  className="group flex flex-col bg-white border border-stone-200 rounded-lg overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md"
                >
                  <div className="aspect-[4/3] w-full bg-[#F6F6F5] overflow-hidden">
                    <SafeImage
                      src={item.image}
                      alt={item.alt}
                      fallbackTitle={item.name}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  </div>

                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex items-center gap-2 text-xs text-stone-500">
                      <span className="font-medium text-[#a65821]">{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate">{item.spec}</span>
                    </div>

                    <div className="mt-2 flex items-baseline justify-between gap-3">
                      <h3 className="font-display text-xl font-bold text-[#1F1C1A] leading-snug">
                        {item.name}
                      </h3>
                      <span className="text-base font-bold text-[#8c1212] tabular-nums shrink-0">
                        {formatBRL(item.price)}
                      </span>
                    </div>

                    <p className="mt-2.5 text-sm text-stone-600 leading-relaxed flex-1">
                      {item.description}
                    </p>

                    {item.highlightNote && (
                      <p className="mt-3 pt-3 border-t border-stone-100 text-xs font-medium text-stone-500">
                        Indicação: {item.highlightNote}
                      </p>
                    )}
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* SERVIÇOS CORPORATIVOS & ESTRUTURA */}
        <section id="servicos" className="py-16 lg:py-24 bg-[#F6F6F5] border-y border-stone-200">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
              <div className="lg:col-span-5">
                <p className="text-xs font-semibold text-[#a65821] tracking-wide mb-2">
                  Serviços & Hospitalidade
                </p>
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1F1C1A] tracking-tight text-balance">
                  Atendimento estruturado para clientes e empresas.
                </h2>
                <p className="mt-4 text-base text-stone-600 leading-relaxed">
                  Localizada em um dos principais corredores comerciais do Recife, a Fã Burguer une
                  hospitalidade executiva e logística precisa para almoços de negócios, entregas
                  empresariais e eventos.
                </p>

                <div className="mt-7">
                  <a
                    href={buildWhatsAppUrl(
                      'Olá, Fã Burguer! Gostaria de falar sobre atendimento corporativo ou reserva.'
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2.5 px-5 py-3 rounded-md bg-[#a65821] hover:bg-[#894618] text-white text-sm font-semibold transition-colors whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>Solicitar Atendimento Corporativo</span>
                  </a>
                </div>
              </div>

              <div className="lg:col-span-7 divide-y divide-stone-200 border-y border-stone-200 bg-white rounded-lg px-6 sm:px-8">
                {CORPORATE_SERVICES.map((service) => (
                  <div key={service.number} className="py-6 sm:py-7">
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
                      <h3 className="font-display text-xl font-bold text-[#1F1C1A]">
                        <span className="text-[#8c1212] mr-2 tabular-nums">{service.number}</span>
                        {service.title}
                      </h3>
                      <a
                        href={buildWhatsAppUrl(service.whatsappPrompt)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8c1212] hover:text-[#700d0d] whitespace-nowrap shrink-0"
                      >
                        <span>Consultar via WhatsApp</span>
                        <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                      </a>
                    </div>
                    <p className="mt-2 text-sm font-medium text-stone-800">{service.summary}</p>
                    <p className="mt-1.5 text-sm text-stone-600 leading-relaxed">
                      {service.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* GALERIA DE FOTOS */}
        <section id="galeria" className="py-16 lg:py-24 bg-white">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-8 border-b border-stone-200">
              <div>
                <p className="text-xs font-semibold text-[#a65821] tracking-wide mb-2">
                  Galeria de Fotos
                </p>
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1F1C1A] tracking-tight text-balance">
                  Salão, Brasa e Apresentação
                </h2>
              </div>
              <p className="text-sm text-stone-600 max-w-md">
                Clique em qualquer fotografia para ampliar os detalhes da nossa estrutura na Av.
                Conde da Boa Vista.
              </p>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
              {GALLERY_PHOTOS.map((photo, index) => {
                const isWide = index === 0 || index === 5;
                return (
                  <button
                    key={photo.id}
                    type="button"
                    onClick={() => setLightboxIndex(index)}
                    className={`group relative overflow-hidden rounded-lg border border-stone-200 bg-[#181615] text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#8c1212] ${
                      isWide ? 'md:col-span-2 aspect-[16/9]' : 'md:col-span-1 aspect-[4/3]'
                    }`}
                  >
                    <SafeImage
                      src={photo.src}
                      alt={photo.alt}
                      fallbackTitle={photo.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-5">
                      <span className="text-xs font-medium text-[#e0915a]">{photo.category}</span>
                      <span className="font-display text-lg font-bold text-white mt-0.5">
                        {photo.title}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* DEPOIMENTOS DE CLIENTES + PROVA QUANTITATIVA */}
        <section id="depoimentos" className="py-16 lg:py-24 bg-[#181615] text-white">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end pb-10 border-b border-stone-800">
              <div className="lg:col-span-7">
                <p className="text-xs font-semibold text-[#e0915a] tracking-wide mb-2">
                  Reconhecimento no Recife
                </p>
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight text-balance">
                  Avaliação de quem frequenta e recomenda a Fã Burguer.
                </h2>
              </div>

              <div className="lg:col-span-5 grid grid-cols-3 gap-4 pt-4 lg:pt-0">
                <div>
                  <p className="font-display text-2xl sm:text-3xl font-bold text-white tabular-nums">
                    +12 anos
                  </p>
                  <p className="text-xs text-stone-400 mt-1">Tradição na Boa Vista</p>
                </div>
                <div>
                  <p className="font-display text-2xl sm:text-3xl font-bold text-white tabular-nums">
                    4,9 / 5,0
                  </p>
                  <p className="text-xs text-stone-400 mt-1">Média dos clientes</p>
                </div>
                <div>
                  <p className="font-display text-2xl sm:text-3xl font-bold text-white tabular-nums">
                    18 min
                  </p>
                  <p className="text-xs text-stone-400 mt-1">Preparo executivo</p>
                </div>
              </div>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">
              {TESTIMONIALS.map((item) => (
                <blockquote
                  key={item.id}
                  className="flex flex-col justify-between p-6 sm:p-7 rounded-lg border border-stone-800 bg-[#201d1b]"
                >
                  <div>
                    <p className="text-xs font-medium text-[#e0915a] mb-3">{item.context}</p>
                    <p className="text-sm sm:text-base text-stone-200 leading-relaxed">
                      “{item.quote}”
                    </p>
                  </div>

                  <footer className="mt-6 pt-5 border-t border-stone-800">
                    <p className="text-sm font-bold text-white">{item.author}</p>
                    <p className="text-xs text-stone-400 mt-0.5">
                      {item.role} · {item.organization}
                    </p>
                    <p className="text-xs text-stone-500 mt-0.5">{item.neighborhood}</p>
                  </footer>
                </blockquote>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ SECTION */}
        <section id="faq" className="py-16 lg:py-24 bg-[#F6F6F5] border-b border-stone-200">
          <div className="max-w-[900px] mx-auto px-4 sm:px-6">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <p className="text-xs font-semibold text-[#a65821] tracking-wide mb-2">
                Dúvidas Frequentes
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1F1C1A] tracking-tight text-balance">
                Informações sobre Pedidos, Salão e Eventos
              </h2>
            </div>

            <div className="divide-y divide-stone-200 border border-stone-200 rounded-lg bg-white">
              {FAQ_ITEMS.map((faq) => {
                const isOpen = openFaqId === faq.id;
                return (
                  <div key={faq.id}>
                    <button
                      type="button"
                      aria-expanded={isOpen}
                      onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                      className="w-full px-6 py-5 text-left flex items-center justify-between gap-4 hover:bg-stone-50 transition-colors cursor-pointer"
                    >
                      <span className="text-sm sm:text-base font-semibold text-[#1F1C1A]">
                        {faq.question}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-stone-500 shrink-0 transition-transform duration-200 ${
                          isOpen ? 'rotate-180 text-[#8c1212]' : ''
                        }`}
                        aria-hidden="true"
                      />
                    </button>
                    {isOpen && (
                      <div className="px-6 pb-5 text-sm text-stone-600 leading-relaxed">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* CONTATO & LOCALIZAÇÃO */}
        <section id="contato" className="py-16 lg:py-24 bg-white">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
              {/* Left Column: Address & Direct WhatsApp */}
              <div className="lg:col-span-5 space-y-6">
                <div>
                  <p className="text-xs font-semibold text-[#a65821] tracking-wide mb-2">
                    Contato & Localização
                  </p>
                  <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1F1C1A] tracking-tight text-balance">
                    Visite a Fã Burguer ou fale com nossa equipe.
                  </h2>
                  <p className="mt-3 text-base text-stone-600 leading-relaxed">
                    Para pedidos rápidos, reservas no mesmo dia ou orçamento de eventos corporativos,
                    nosso canal prioritário é o WhatsApp.
                  </p>
                </div>

                <div className="border border-stone-200 rounded-lg divide-y divide-stone-200 bg-[#F6F6F5]">
                  <div className="p-5 flex items-start gap-3.5">
                    <MapPin className="w-5 h-5 text-[#8c1212] shrink-0 mt-0.5" aria-hidden="true" />
                    <div>
                      <p className="text-xs font-semibold text-stone-500">Endereço Oficial</p>
                      <p className="text-sm font-semibold text-[#1F1C1A] mt-0.5">
                        {RESTAURANT_INFO.address}
                      </p>
                    </div>
                  </div>

                  <div className="p-5 flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3.5">
                      <Phone
                        className="w-5 h-5 text-[#8c1212] shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <div>
                        <p className="text-xs font-semibold text-stone-500">
                          Telefone / WhatsApp
                        </p>
                        <p className="text-sm font-semibold text-[#1F1C1A] tabular-nums mt-0.5">
                          {RESTAURANT_INFO.phoneDisplay}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleCopyPhone}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-stone-300 bg-white text-xs font-semibold text-stone-700 hover:text-[#8c1212] hover:border-[#8c1212] transition-colors cursor-pointer shrink-0"
                    >
                      {phoneCopied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                          <span>Copiado</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Copiar</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="p-5 flex items-start gap-3.5">
                    <Clock className="w-5 h-5 text-[#8c1212] shrink-0 mt-0.5" aria-hidden="true" />
                    <div>
                      <p className="text-xs font-semibold text-stone-500">
                        Horário de Funcionamento
                      </p>
                      <p className="text-sm font-semibold text-[#1F1C1A] tabular-nums mt-0.5">
                        {RESTAURANT_INFO.hours}
                      </p>
                    </div>
                  </div>
                </div>

                <a
                  href={buildWhatsAppUrl(
                    'Olá, Fã Burguer! Gostaria de falar com o atendimento.'
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-md bg-[#8c1212] hover:bg-[#700d0d] text-white text-sm font-semibold transition-colors whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Conversar Agora pelo WhatsApp</span>
                </a>
              </div>

              {/* Right Column: Validated Lead / Contact Form */}
              <div className="lg:col-span-7 border border-stone-200 rounded-lg p-6 sm:p-8 bg-white">
                <h3 className="font-display text-2xl font-bold text-[#1F1C1A]">
                  Formulário de Contato & Reservas
                </h3>
                <p className="text-sm text-stone-600 mt-1">
                  Preencha seus dados abaixo para registrar sua mensagem ou enviá-la diretamente ao
                  nosso WhatsApp corporativo.
                </p>

                {contactSubmitted ? (
                  <div
                    role="status"
                    className="mt-6 p-6 rounded-lg border border-emerald-200 bg-emerald-50 space-y-4"
                  >
                    <div className="flex items-start gap-3">
                      <CheckCircle2
                        className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <div>
                        <h4 className="text-sm font-bold text-emerald-950">
                          Solicitação registrada com sucesso
                        </h4>
                        <p className="text-sm text-emerald-900 mt-1 leading-relaxed">
                          Obrigado, {contactName}. Para acelerar sua resposta sobre{' '}
                          <strong>{contactSubject}</strong>, clique no botão abaixo para encaminhar
                          os dados preenchidos diretamente para o WhatsApp da Fã Burguer.
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 pt-1">
                      <a
                        href={contactWhatsAppHref}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-md bg-[#8c1212] hover:bg-[#700d0d] text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap"
                      >
                        <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                        <span>Enviar Mensagem no WhatsApp</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => {
                          setContactSubmitted(false);
                          setContactName('');
                          setContactPhone('');
                          setContactEmail('');
                          setContactMessage('');
                        }}
                        className="px-4 py-2.5 rounded-md border border-emerald-300 text-xs sm:text-sm font-semibold text-emerald-900 hover:bg-emerald-100 transition-colors cursor-pointer"
                      >
                        Nova mensagem
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleContactSubmit} noValidate className="mt-6 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="contact-name"
                          className="block text-xs font-semibold text-stone-700 mb-1.5"
                        >
                          Nome completo *
                        </label>
                        <input
                          id="contact-name"
                          type="text"
                          required
                          value={contactName}
                          onChange={(e) => setContactName(e.target.value)}
                          placeholder="Seu nome"
                          className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] placeholder:text-stone-400 focus:outline-none focus:border-[#8c1212]"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="contact-phone"
                          className="block text-xs font-semibold text-stone-700 mb-1.5"
                        >
                          Telefone / WhatsApp *
                        </label>
                        <input
                          id="contact-phone"
                          type="tel"
                          required
                          value={contactPhone}
                          onChange={(e) => setContactPhone(e.target.value)}
                          placeholder="(81) 99999-9999"
                          className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] placeholder:text-stone-400 focus:outline-none focus:border-[#8c1212]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="contact-email"
                          className="block text-xs font-semibold text-stone-700 mb-1.5"
                        >
                          E-mail *
                        </label>
                        <input
                          id="contact-email"
                          type="email"
                          required
                          value={contactEmail}
                          onChange={(e) => setContactEmail(e.target.value)}
                          placeholder="voce@empresa.com.br"
                          className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] placeholder:text-stone-400 focus:outline-none focus:border-[#8c1212]"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="contact-subject"
                          className="block text-xs font-semibold text-stone-700 mb-1.5"
                        >
                          Assunto
                        </label>
                        <select
                          id="contact-subject"
                          value={contactSubject}
                          onChange={(e) => setContactSubject(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] focus:outline-none focus:border-[#8c1212]"
                        >
                          <option value="Reserva de Mesa">Reserva de Mesa</option>
                          <option value="Evento / Pedido Corporativo">
                            Evento / Pedido Corporativo
                          </option>
                          <option value="Delivery & Cardápio">Delivery & Cardápio</option>
                          <option value="Sugestões & Imprensa">Sugestões & Imprensa</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-message"
                        className="block text-xs font-semibold text-stone-700 mb-1.5"
                      >
                        Mensagem *
                      </label>
                      <textarea
                        id="contact-message"
                        rows={4}
                        required
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        placeholder="Informe data, horário, número de pessoas ou detalhes da sua solicitação."
                        className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-md bg-white text-[#1F1C1A] placeholder:text-stone-400 focus:outline-none focus:border-[#8c1212]"
                      />
                    </div>

                    {contactError && (
                      <div
                        role="alert"
                        className="flex items-start gap-2.5 p-3 rounded-md bg-red-50 border border-red-200 text-xs text-[#8c1212]"
                      >
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
                        <span>{contactError}</span>
                      </div>
                    )}

                    <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
                      <button
                        type="submit"
                        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-md bg-[#8c1212] hover:bg-[#700d0d] text-white text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <span>Enviar Solicitação</span>
                        <ArrowRight className="w-4 h-4 shrink-0" aria-hidden="true" />
                      </button>

                      <a
                        href={contactWhatsAppHref}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-semibold text-stone-600 hover:text-[#8c1212] transition-colors"
                      >
                        Prefere ir direto para o WhatsApp?
                      </a>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* QUIET CORPORATE FOOTER */}
      <footer className="bg-[#181615] text-stone-400 border-t border-stone-800">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-stone-800">
            <div className="md:col-span-5">
              <p className="font-display text-2xl font-bold text-white">{RESTAURANT_INFO.name}</p>
              <p className="mt-3 text-sm text-stone-400 leading-relaxed max-w-sm">
                Hamburgueria renomada na Boa Vista, Recife. Compromisso com cortes nobres na brasa,
                atendimento executivo e agilidade pelo WhatsApp.
              </p>
            </div>

            <div className="md:col-span-4 space-y-2 text-sm">
              <p className="font-semibold text-white">Endereço & Contato</p>
              <p className="text-stone-400">{RESTAURANT_INFO.address}</p>
              <p className="text-stone-300 tabular-nums">{RESTAURANT_INFO.phoneDisplay}</p>
              <p className="text-stone-400 tabular-nums">{RESTAURANT_INFO.hours}</p>
            </div>

            <div className="md:col-span-3 space-y-2 text-sm">
              <p className="font-semibold text-white">Navegação</p>
              <ul className="space-y-1.5">
                <li>
                  <a href="#cardapio" className="hover:text-white transition-colors">
                    Cardápio
                  </a>
                </li>
                <li>
                  <a href="#servicos" className="hover:text-white transition-colors">
                    Serviços Corporativos
                  </a>
                </li>
                <li>
                  <a href="#galeria" className="hover:text-white transition-colors">
                    Galeria de Fotos
                  </a>
                </li>
                <li>
                  <a href="#depoimentos" className="hover:text-white transition-colors">
                    Depoimentos
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-white transition-colors">
                    Perguntas Frequentes
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-stone-500">
            <p>© 2026 Fã Burguer. Todos os direitos reservados.</p>
            <a
              href={buildWhatsAppUrl('Olá, Fã Burguer! Gostaria de fazer um pedido.')}
              target="_blank"
              rel="noopener noreferrer"
              className="text-stone-300 hover:text-white font-medium transition-colors"
            >
              WhatsApp Oficial: {RESTAURANT_INFO.phoneDisplay}
            </a>
          </div>
        </div>
      </footer>

      {/* Photo Lightbox Modal */}
      <LightboxModal
        photos={GALLERY_PHOTOS}
        activeIndex={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onNavigate={(nextIndex) => setLightboxIndex(nextIndex)}
      />
    </div>
  );
}
